Lab11 Eagle Support Files
=========================

Part libraries, packaging scripts, CAM jobs, and other files we use with [EAGLE](https://www.autodesk.com/products/eagle/overview).

We highly recommend reading over some of the [Lab11 Eagle Documentation](doc/).
